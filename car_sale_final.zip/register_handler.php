<?php
// register_handler.php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// ͳһ���� config.php
require 'config.php';

$input = json_decode(file_get_contents('php://input'), true);
$response = ['success' => false, 'message' => ''];

if (empty($input)) {
    $response['message'] = 'No form data received';
    echo json_encode($response);
    exit();
}

$role = $input['role'] ?? '';
$fullName = trim($input['fullName'] ?? '');
$address = trim($input['address'] ?? '');
$phone = trim($input['phone'] ?? '');
$email = trim($input['email'] ?? '');
$username = trim($input['username'] ?? '');
$password = trim($input['password'] ?? '');

// Check if username/phone/email already exists using PDO
$checkSql = "SELECT * FROM users WHERE username = ? OR phone = ? OR email = ?";
$checkStmt = $pdo->prepare($checkSql);
$checkStmt->execute([$username, $phone, $email]);
$checkResult = $checkStmt->fetchAll();

if (count($checkResult) > 0) {
    $row = $checkResult[0];
    if ($row['username'] === $username) {
        $response['message'] = 'Username already exists';
    } elseif ($row['phone'] === $phone) {
        $response['message'] = 'Phone number already registered';
    } else {
        $response['message'] = 'Email already registered';
    }
    echo json_encode($response);
    exit();
}

$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

$insertSql = "INSERT INTO users (role, fullName, address, phone, email, username, password) 
              VALUES (?, ?, ?, ?, ?, ?, ?)";
$insertStmt = $pdo->prepare($insertSql);

if ($insertStmt->execute([$role, $fullName, $address, $phone, $email, $username, $hashedPassword])) {
    $response['success'] = true;
    $response['message'] = 'Registration successful!';
} else {
    $response['message'] = 'Registration failed.';
}

echo json_encode($response);
?>