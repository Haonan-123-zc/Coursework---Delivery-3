<?php
// config.php
$host = '127.0.0.1';
$dbname = 'car_sale_db'; // ͳһʹ��������ݿ���
$db_user = 'root';     
$db_pass = '';         // XAMPP Ĭ������Ϊ��

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $db_user, $db_pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>