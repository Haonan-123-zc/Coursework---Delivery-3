<?php
session_start();
require 'config.php';

$keyword = trim($_GET['keyword'] ?? '');
$carList = [];
$isSearch = false;

// 如果用户输入了搜索词，执行查询
if (!empty($keyword)) {
    $isSearch = true;
    // 模糊查询：车型、颜色或地点
    $sql = "SELECT * FROM cars WHERE model LIKE :keyword OR colour LIKE :keyword OR location LIKE :keyword";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':keyword', "%$keyword%");
    $stmt->execute();
    $carList = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Search System</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: sans-serif; }
        body { background: url("https://images.unsplash.com/photo-1494976388531-d1058494cdd8?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80") no-repeat center center; background-size: cover; background-attachment: fixed; min-height: 100vh; color: #fff; }
        .nav { background:rgba(255,255,255,0.95); padding:16px; text-align:center; box-shadow:0 2px 10px rgba(0,0,0,0.1); }
        .nav a{ margin:0 12px; text-decoration:none; color:#333; font-weight:500; }
        .nav a.active{ color:#0066ff; font-weight:bold; }
        .mask { width: 100%; min-height: 100vh; background-color: rgba(0, 0, 0, 0.55); padding: 40px 0; }
        .header { text-align: center; margin-bottom: 60px; }
        .header h1 { font-size: 48px; margin-bottom: 15px; letter-spacing: 2px; }
        .header p { font-size: 18px; opacity: 0.9; }
        .search-box { width: 60%; margin: 0 auto 80px; background: rgba(255, 255, 255, 0.15); backdrop-filter: blur(10px); padding: 30px; border-radius: 16px; border: 1px solid rgba(255, 255, 255, 0.2); }
        .search-input { display: flex; gap: 10px; margin-bottom: 20px; }
        .search-input input { flex: 1; padding: 15px 20px; border-radius: 8px; border: none; font-size: 16px; outline: none; }
        .search-btn { padding: 15px 30px; background: #0066ff; color: #fff; border: none; border-radius: 8px; cursor: pointer; font-size: 16px; transition: 0.3s; }
        .search-btn:hover { background: #0052cc; }
        .img-search { text-align: center; padding: 20px; border: 2px dashed rgba(255, 255, 255, 0.4); border-radius: 8px; }
        #carImg { display: none; }
        input[type="file"] { color: transparent; }
        .news-wrap { width: 80%; margin: 0 auto; }
        .news-title { font-size: 28px; margin-bottom: 30px; border-left: 5px solid #0066ff; padding-left: 15px; }
        .news-list { display: grid; grid-template-columns: repeat(3, 1fr); gap: 25px; }
        .news-item { background: rgba(255, 255, 255, 0.12); backdrop-filter: blur(8px); border-radius: 12px; overflow: hidden; transition: 0.3s; }
        .news-item:hover { transform: translateY(-5px); background: rgba(255, 255, 255, 0.2); }
        .news-item img { width: 100%; height: 180px; object-fit: cover; }
        .news-content { padding: 15px; }
        .news-content h3 { font-size: 16px; margin-bottom: 10px; line-height: 1.5; color: #fff;}
        .news-content p { font-size: 13px; opacity: 0.8; line-height: 1.6; color: #ddd;}
        .no-result { text-align: center; font-size: 18px; padding: 40px; background: rgba(255, 0, 0, 0.2); border-radius: 12px;}
    </style>
</head>
<body>
    <div class="nav">
        <a href="index.html">Home</a>
        <a href="search.php" class="active">Search Cars</a>
        <a href="seller.php">Seller Center</a>
        <a href="register.html">Register</a>
        <a href="login.html">Login</a>
    </div>

    <div class="mask">
        <div class="header">
            <h1>Car Search System</h1>
            <p>Text Search | Image Recognition | Hot Automotive News</p>
        </div>

        <div class="search-box">
            <form action="search.php" method="get">
                <div class="search-input">
                    <input type="text" name="keyword" value="<?= htmlspecialchars($keyword) ?>" placeholder="Search for model, color, location...">
                    <button class="search-btn" type="submit">Search</button>
                </div>
            </form>

            <div class="img-search">
                <label for="carImg">Upload Image for Vehicle Search</label>
                <input type="file" id="carImg" accept="image/*">
            </div>
        </div>

        <div class="news-wrap">
            <?php if ($isSearch): ?>
                <h2 class="news-title">Search Results</h2>
                
                <?php if (count($carList) > 0): ?>
                    <div class="news-list">
                        <?php foreach ($carList as $car): ?>
                            <div class="news-item">
                                <img src="<?= htmlspecialchars($car['image_path']) ?>" alt="Car Image" onerror="this.src='https://images.unsplash.com/photo-1555215695-3004980ad54e?ixlib=rb-4.0.3&w=600&q=80'">
                                <div class="news-content">
                                    <h3><?= htmlspecialchars($car['model']) ?></h3>
                                    <p><strong>Price:</strong> ¥<?= htmlspecialchars($car['price']) ?></p>
                                    <p><strong>Year:</strong> <?= htmlspecialchars($car['year']) ?></p>
                                    <p><strong>Color:</strong> <?= htmlspecialchars($car['colour']) ?></p>
                                    <p><strong>Location:</strong> <?= htmlspecialchars($car['location']) ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="no-result">No cars found matching "<?= htmlspecialchars($keyword) ?>"</div>
                <?php endif; ?>

            <?php else: ?>
                <h2 class="news-title">Hot News</h2>
                <div class="news-list">
                    <div class="news-item">
                        <img src="https://images.unsplash.com/photo-1555215695-3004980ad54e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Car">
                        <div class="news-content">
                            <h3>New Energy Vehicles Lead The Market</h3>
                            <p>Hybrid and electric cars become mainstream with advanced energy-saving technology.</p>
                        </div>
                    </div>
                    <div class="news-item">
                        <img src="https://images.unsplash.com/photo-1552519507-da3b142c6e3d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Car">
                        <div class="news-content">
                            <h3>New Luxury Cars Released</h3>
                            <p>Intelligent cockpit and autonomous driving functions fully upgraded.</p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        const fileInput = document.getElementById('carImg');
        fileInput.addEventListener('change', function(){
            alert("Image selected, ready to search (Feature coming soon)");
        });
    </script>
</body>
</html>