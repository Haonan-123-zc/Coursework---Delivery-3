<?php
session_start();
require 'config.php';

// �����ʵ��¼״̬����Ҳ���Ǽ�������
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Please login first to sell a car!'); location.href='login.html';</script>";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // ��ȡ��ʵ��¼���ҵ� ID
    $seller_id = $_SESSION['user_id']; 
    
    $colour = trim($_POST['colour']);
    $model = trim($_POST['model']);
    $year = (int)$_POST['year'];
    $location = trim($_POST['location']);
    $price = $_POST['price'];

    $image_path = ""; 
    if (isset($_FILES['carImage']) && $_FILES['carImage']['error'] == 0) {
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
        
        $file_name = time() . "_" . basename($_FILES["carImage"]["name"]); 
        $target_file = $target_dir . $file_name;

        if (move_uploaded_file($_FILES["carImage"]["tmp_name"], $target_file)) {
            $image_path = $target_file; 
        }
    }

    try {
        $sql = "INSERT INTO cars (seller_id, colour, model, year, location, price, image_path) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$seller_id, $colour, $model, $year, $location, $price, $image_path]);
        
        echo "<script>alert('Car posted successfully!'); location.href='seller.php';</script>";
    } catch (PDOException $e) {
        echo "<script>alert('Error: Could not save data.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>AutoMarket - Add New Car</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif; }
        body { background: linear-gradient(145deg, #f4f7fc 0%, #e9eef3 100%); min-height: 100vh; padding: 0 20px 40px; }
        .nav { background:#0a2b3e; padding:16px; text-align:center; }
        .nav a { color:#fff; margin:0 12px; text-decoration:none; }
        .nav a.active { color:#ffaa33; font-weight:bold; }
        .app-container { max-width: 1300px; margin: 0 auto; }
        .form-card { background: #ffffff; border-radius: 36px; box-shadow: 0 25px 45px -12px rgba(0,0,0,0.2); overflow: hidden; margin:30px 0; }
        .card-header { background: #0f2f3f; padding: 24px 32px; color: white; }
        .card-header h1 { font-size: 1.9rem; font-weight: 700; display: flex; align-items: center; gap: 14px; }
        .card-header h1 i { color: #ffaa33; font-size: 2rem; }
        .card-header p { color: #cfe4f0; margin-top: 8px; font-size: 1rem; }
        .form-body { padding: 32px 36px; }
        .form-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 28px 32px; }
        .full-width { grid-column: span 2; }
        .input-group { display: flex; flex-direction: column; gap: 8px; }
        .input-group label { font-weight: 600; color: #1e2f3a; font-size: 0.95rem; display: flex; align-items: center; gap: 8px; }
        .input-group label i { color: #ffaa33; width: 20px; }
        .input-group input,.input-group select { padding: 14px 18px; border: 1.5px solid #e2e8f0; border-radius: 24px; font-size: 1rem; transition: all 0.2s; background: #fefefe; outline: none; }
        .input-group input:focus,.input-group select:focus { border-color: #ffaa33; box-shadow: 0 0 0 3px rgba(255,170,51,0.2); }
        .btn-submit { background: #0a2b3e; border: none; padding: 16px 28px; font-size: 1.1rem; font-weight: 700; border-radius: 50px; color: white; cursor: pointer; transition: 0.2s; display: inline-flex; align-items: center; justify-content: center; gap: 12px; width: 100%; margin-top: 20px; }
        .btn-submit:hover { background: #ffaa33; color: #0a2b3e; transform: translateY(-2px); }
        @media (max-width: 880px) { .form-grid {grid-template-columns: 1fr;} .full-width {grid-column: span 1;} }
    </style>
</head>
<body>
    <div class="nav">
        <a href="index.html">Home</a>
        <a href="search.php">Search Cars</a>
        <a href="seller.php" class="active">Sell Car</a>
        <a href="register.html">Register</a>
        <a href="login.html">Login</a>
    </div>

    <div class="app-container">
        <div class="form-card">
            <div class="card-header">
                <h1><i class="fas fa-car"></i> Post Car Listing</h1>
                <p>Fill in car details and list for sale to reach thousands of buyers</p>
            </div>
            <div class="form-body">
                <form id="addCarForm" method="POST" enctype="multipart/form-data">
                    <div class="form-grid">
                        <div class="input-group">
                            <label><i class="fas fa-palette"></i> Exterior Color *</label>
                            <input type="text" id="colour" name="colour" placeholder="Letters, spaces only" required>
                        </div>
                        <div class="input-group">
                            <label><i class="fas fa-car"></i> Car Model *</label>
                            <input type="text" id="model" name="model" placeholder="Brand + Model" required>
                        </div>
                        <div class="input-group">
                            <label><i class="fas fa-calendar-alt"></i> Manufacture Year *</label>
                            <input type="number" id="year" name="year" min="1900" max="2026" required>
                        </div>
                        <div class="input-group">
                            <label><i class="fas fa-map-marker-alt"></i> Location *</label>
                            <input type="text" id="location" name="location" required>
                        </div>
                        <div class="input-group">
                            <label><i class="fas fa-dollar-sign"></i> Price *</label>
                            <input type="text" id="price" name="price" placeholder="Positive number, max 2 decimals" required>
                        </div>
                        <div class="input-group full-width">
                            <label><i class="fas fa-image"></i> Car Image *</label>
                            <input type="file" id="carImage" name="carImage" accept="image/jpeg,image/png,image/webp" required>
                        </div>
                    </div>
                    <button type="submit" class="btn-submit">Publish Car</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>