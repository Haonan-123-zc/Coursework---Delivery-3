<?php
// login.php
session_start();
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: login.html");
    exit();
}

$account = $_POST['account'];
$pwd = $_POST['pwd'];

$sql = "SELECT id, username, password, role FROM users WHERE username = :account LIMIT 1";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':account', $account);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// ��֤���룬�ɹ����¼��ʵ�� user_id
if ($user && password_verify($pwd, $user['password'])) {
    $_SESSION['user_id'] = $user['id']; // ��������ĵ�Ѫ����
    $_SESSION['username'] = $user['username'];
    $_SESSION['role'] = $user['role'];
    header("Location: index.html");
    exit();
} else {
    echo "<script>alert('Incorrect account or password'); history.back();</script>";
    exit();
}
?>